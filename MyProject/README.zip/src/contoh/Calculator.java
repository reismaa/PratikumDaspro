package contoh;

public class Calculator {

    // Method untuk menjumlahkan dua angka
    public int add(int codeInput1, int codeInput2) {
    
    // Hasil penjumlahan dua angka (codeInput 1 + codeInput2)
        int hasil = 0;
        hasil = codeInput1 + codeInput2;
        return hasil; // Mengembalikan hasil penjumlahan
    }
    
}
