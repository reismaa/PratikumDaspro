package FunctionSimple;

public class Function1 {
    
    // Fungsi yang digunakan untuk menjumlahkan dua bilangan
    public int add(int a, int b) {
        // proses penjumlahan sederhana
        int hasil = a + b;
        return hasil;
    }

    // Fungsi yang digunakan untuk mengalikan dua bilangan
    public int multiply(int a, int b) {
        // proses perkalian sederhana
        int hasil = a * b;
        return hasil;
    }
}
